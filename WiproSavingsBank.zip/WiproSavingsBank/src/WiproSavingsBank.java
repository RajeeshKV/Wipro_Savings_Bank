import java.util.Date;

class WiproBank{
	int acno, age;
	String name, address, statement ="";
	float avail_bal, min_bal;
	Date d;
	
	WiproBank(int tacno, String tname, String taddress, int tage, float tmin){
		acno = tacno;
		name = tname;
		address = taddress;
		age = tage;
		min_bal = tmin;
		avail_bal = tmin;
	}
	
	void Deposit(float bal){
		avail_bal += bal;
		System.out.println(name + ", balance deposited");
		d = new Date();
		statement += d + " - " + bal + " deposited\n";
	}
	void Withdraw(float bal){
		if(avail_bal - bal < min_bal){
			System.out.println(name + ", Cannot withdraw money");
		}
		else{
			avail_bal -= bal;
			System.out.println(name + ", balance deducted");
			d = new Date();
			statement += d + " - " + bal + " deducted\n";
		}
	}
	void display(){
		System.out.println(name + ", current balance is : " + avail_bal);
	}
	
	void MiniStatement(){
		System.out.println("======MiniStatemenet======");
		System.out.println(statement);
	}
}

class WiproSavingsBank{
	public static void main(String args[]){
		int accno = 11111;
		WiproBank cust1 = new WiproBank(accno++, "Rajeesh", "Kerala", 21, 500);
		WiproBank cust2 = new WiproBank(accno++, "Akshay", "Karnataka", 22, 1500);
		
		cust1.Deposit(1000);
		cust2.Deposit(2000);
		cust1.Withdraw(500);
		cust2.Withdraw(2500);
		cust1.display();
		cust2.display();
		cust1.MiniStatement();
		cust2.MiniStatement();
	}
}



/*
1) Static variables and instance variables both are member variables of a specific class. 
The difference between them is static variables only have one copy that is shared by all
the different objects of a class, whereas every object has it's own personal copy for
instance variable.


2) Encapsulation is the method of wrapping up of data into a single unit. Here we can see
that all the properties and methods are combined together into a class named WiproBank. We
can easily manupulate data using this technique.

/*
